'use client';
import React, { useState } from 'react';
import './globals.css';
import cfg from '../config.json';

export default function Page() {
  const [lightbox, setLightbox] = useState<string | null>(null);

  const LOGO_SRC = '/logo-dermo-ink.png';
  const WHATSAPP_NUMBER = cfg.whatsapp;
  const INSTAGRAM_USER = cfg.instagram;
  const ADDRESS = cfg.address;
  const CITY = cfg.city;

  const WA_URL = (text: string) => `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
  const IG_DM_URL = `https://ig.me/m/${INSTAGRAM_USER}`;
  const IG_PROFILE_URL = `https://instagram.com/${INSTAGRAM_USER}`;

  const gallery: string[] = [
    '/galeria/01.webp',
    '/galeria/02.webp',
    '/galeria/03.webp',
    '/galeria/04.webp',
    '/galeria/05.webp',
    '/galeria/06.webp',
  ];

  const nav = [
    { id: 'inicio', label: 'Inicio' },
    { id: 'servicios', label: 'Servicios' },
    { id: 'galeria', label: 'Galería' },
    { id: 'contacto', label: 'Contacto' },
  ];

  return (
    <main className="min-h-screen bg-black text-white scroll-smooth">
      <header className="fixed top-0 z-40 w-full border-b border-white/10 bg-black/70 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <img src={LOGO_SRC} alt="Dermo Ink" className="h-8 w-auto" />
            <span className="hidden text-lg font-light tracking-widest sm:block">DERMO INK</span>
          </div>
          <nav className="hidden gap-6 md:flex">
            {nav.map((n) => (
              <a key={n.id} href={`#${n.id}`} className="text-sm text-white/80 hover:text-white">
                {n.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <a
              href={WA_URL('Hola, quiero una cita / cotización en Dermo Ink')}
              target="_blank"
              rel="noreferrer"
              className="rounded-full bg-red-600 px-4 py-2 text-sm font-medium hover:bg-red-500"
            >
              WhatsApp
            </a>
            <a
              href={IG_DM_URL}
              target="_blank"
              rel="noreferrer"
              className="hidden rounded-full border border-white/30 px-4 py-2 text-sm hover:border-white md:inline"
            >
              Instagram
            </a>
          </div>
        </div>
      </header>

      <section id="inicio" className="relative flex min-h-screen items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(229,9,20,0.18),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.06),transparent_60%)]" />
        </div>
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-6 py-24 md:grid-cols-2">
          <div>
            <h1 className="text-4xl font-light leading-tight tracking-wide md:text-6xl">
              Arte que <span className="font-medium text-red-500">cuida</span> tu piel
            </h1>
            <p className="mt-6 max-w-xl text-lg text-white/80">
              Tatuajes personalizados, perforaciones seguras y Hollywood Peel. Contáctanos por WhatsApp o Instagram.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href={WA_URL('Hola, me interesa agendar / cotizar')} target="_blank" rel="noreferrer" className="rounded-full bg-white px-5 py-3 text-black hover:bg-white/90">Hablar por WhatsApp</a>
              <a href={`https://ig.me/m/${INSTAGRAM_USER}`} target="_blank" rel="noreferrer" className="rounded-full border border-white/30 px-5 py-3 hover:border-white">Escribir por Instagram</a>
            </div>
            <div className="mt-6 text-sm text-white/60">Dirección: <span className="font-medium text-white">{ADDRESS}, {CITY}</span></div>
          </div>
          <div className="justify-self-center">
            <div className="relative aspect-[4/5] w-full max-w-sm overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-neutral-900 to-neutral-950 shadow-2xl">
              <div className="absolute inset-0 opacity-15" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1280&auto=format&fit=crop')", backgroundSize: 'cover', backgroundPosition: 'center' }} />
              <div className="absolute bottom-0 left-0 right-0 space-y-4 p-6">
                <p className="text-sm uppercase tracking-[0.25em] text-white/70">Dermo Ink</p>
                <h3 className="text-2xl font-light">Studio & Skin</h3>
                <p className="text-white/70">Higiene rigurosa · Materiales certificados · Seguimiento</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="servicios" className="border-y border-white/10 bg-black py-16">
        <div className="mx-auto max-w-7xl px-6">
          <header className="mb-8">
            <p className="text-sm uppercase tracking-[0.3em] text-red-500">Servicios</p>
            <h2 className="mt-2 text-3xl font-light md:text-4xl">Tatuajes · Perforaciones · Hollywood Peel</h2>
            <p className="mt-3 max-w-2xl text-white/70">Personalización, bioseguridad y acompañamiento de cicatrización. Escríbenos y resolvemos tus dudas.</p>
          </header>
          <div className="grid gap-6 md:grid-cols-3">
            {[{t:'Tatuajes',d:'Black & Grey, color, fineline, cover-up y microrealismo.'},{t:'Perforaciones',d:'Joyería inicial de titanio/ACF, colocación aséptica y controles.'},{t:'Hollywood Peel',d:'Peeling de carbón activado con láser para textura y luminosidad.'}].map((s)=> (
              <div key={s.t} className="rounded-2xl border border-white/10 bg-neutral-950 p-6">
                <h3 className="text-xl font-medium">{s.t}</h3>
                <p className="mt-2 text-white/70">{s.d}</p>
                <div className="mt-4 flex gap-3">
                  <a href={WA_URL(`Hola, quiero info sobre ${s.t}`)} target="_blank" rel="noreferrer" className="rounded-full bg-red-600 px-4 py-2 text-sm hover:bg-red-500">WhatsApp</a>
                  <a href={`https://ig.me/m/${INSTAGRAM_USER}`} target="_blank" rel="noreferrer" className="rounded-full border border-white/20 px-4 py-2 text-sm hover:border-white">Instagram</a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="galeria" className="bg-neutral-50 py-20 text-neutral-900">
        <div className="mx-auto max-w-7xl px-6">
          <header className="mb-8">
            <p className="text-sm uppercase tracking-[0.3em] text-red-600">Portafolio</p>
            <h2 className="mt-2 text-3xl font-light md:text-4xl">Galería</h2>
            <p className="mt-2 max-w-2xl text-neutral-700">Sube tus fotos a <code>/public/galeria</code> y agrega las rutas al arreglo <code>gallery</code>. Optimiza a 1600px de ancho y formato WebP/JPG.</p>
          </header>
          <div className="columns-1 gap-4 sm:columns-2 md:columns-3">
            {gallery.map((src, i) => (
              <button key={src} onClick={() => setLightbox(src)} className="mb-4 block w-full overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
                <img src={src} alt={`Foto ${i+1}`} className="w-full object-cover" loading="lazy" />
              </button>
            ))}
          </div>
          {lightbox && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={() => setLightbox(null)}>
              <img src={lightbox} alt="Zoom" className="max-h-[90vh] max-w-[90vw] rounded-xl" />
            </div>
          )}
        </div>
      </section>

      <section id="contacto" className="relative bg-black py-20">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_center,rgba(229,9,20,0.1),transparent_55%)]" />
        <div className="mx-auto max-w-7xl px-6">
          <header className="mb-8">
            <p className="text-sm uppercase tracking-[0.3em] text-red-500">Contacto</p>
            <h2 className="mt-2 text-3xl font-light md:text-4xl">Hablemos</h2>
          </header>
          <div className="grid gap-8 md:grid-cols-2">
            <div className="rounded-2xl border border-white/10 bg-neutral-950 p-6">
              <h3 className="text-xl font-medium">Escríbenos</h3>
              <p className="mt-2 text-white/70">Atención por mensaje. Responderemos lo antes posible.</p>
              <div className="mt-4 flex flex-wrap gap-3">
                <a href={WA_URL('Hola, me gustaría agendar / cotizar')} target="_blank" rel="noreferrer" className="rounded-full bg-white px-4 py-2 text-black hover:bg-white/90">WhatsApp</a>
                <a href={`https://ig.me/m/${INSTAGRAM_USER}`} target="_blank" rel="noreferrer" className="rounded-full border border-white/20 px-4 py-2 hover:border-white">Instagram (DM)</a>
                <a href={`https://instagram.com/${INSTAGRAM_USER}`} target="_blank" rel="noreferrer" className="rounded-full border border-white/20 px-4 py-2 hover:border-white">Ver perfil IG</a>
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-neutral-950 p-6">
              <h3 className="text-xl font-medium">Dónde estamos</h3>
              <p className="mt-2 text-white/70">Dirección: <strong>{ADDRESS}, {CITY}</strong></p>
              <p className="text-white/70">Horarios: Lun–Sáb 11:00–20:00</p>
              <div className="mt-4 overflow-hidden rounded-xl border border-white/10">
                <iframe
                  title="Mapa"
                  src={`https://maps.google.com/maps?q=${encodeURIComponent(`${ADDRESS}, ${CITY}`)}&t=&z=14&ie=UTF8&iwloc=&output=embed`}
                  className="h-64 w-full"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 bg-black py-10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 md:flex-row">
          <div className="flex items-center gap-3">
            <img src={LOGO_SRC} alt="Dermo Ink" className="h-6 w-auto" />
            <span className="text-sm text-white/60">© {new Date().getFullYear()} Dermo Ink. Todos los derechos reservados.</span>
          </div>
          <div className="flex gap-6 text-sm text-white/60">
            <a href="#" className="hover:text-white">Política de privacidad</a>
            <a href="#" className="hover:text-white">Consentimiento informado</a>
            <a href="#" className="hover:text-white">Política de cancelación</a>
          </div>
        </div>
      </footer>
    </main>
  );
}
