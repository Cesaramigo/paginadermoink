export default { reactStrictMode: true, images: { domains: ['images.unsplash.com'] } };
